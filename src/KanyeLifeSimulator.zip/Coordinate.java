public class Coordinate {

    public int xpos;
    public int ypos;
    public int neighbors;


    Coordinate(int xpos, int ypos) {
        this.xpos = xpos;
        this.ypos = ypos;
    }
}
